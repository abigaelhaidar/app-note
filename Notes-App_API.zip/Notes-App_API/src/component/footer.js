class Footer extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          background-color: #A66E38;
          color: #fff;
          text-align: center;
        }
        .footer {
          max-width: 1200px;
          margin: 0 auto;
          padding: 1rem;
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
        }

        .footer p{
          font-size: 20px;
        }


        /* Media query untuk tablet */
        @media (max-width: 768px) {
          .footer {
            padding: 1rem 0.5rem;
          }
          .footer p {
            font-size: 18px;
          }
        }

        /* Media query untuk hp */
        @media (max-width: 480px) {
          .footer {
            padding: 1rem 0.5rem;
          }
          .footer p {
            font-size: 16px;
          }

      </style>

          <div class="footer">
              <p>&copy; 2024 Note-APP || by Abigael Haidar</p>
          </div>
    `;
  }
}

customElements.define('footer-app', Footer);
