class Navbar extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
    <header>
      <nav>
        <h1>Note's</h1>
      </nav>
    </header>

    <style>
      :host {
        display: block;
      }

      header {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #A66E38;
        position: fixed;
        top: 0;
        z-index: 10;
        width: 100%;
        height: 100px;
      }

      nav {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
      }

      h1 {
        margin: 0;
        color: white; 
        font-size: 2.2rem;
      }

      /* Media query untuk tablet */
      @media (max-width: 768px) {
        header {
          height: 80px;
        }
        h1 {
          font-size: 1.8rem;
        }
      }

      /* Media query untuk hp */
      @media (max-width: 480px) {
        header {
          height: 60px;
        }
        h1 {
          font-size: 1.5rem;
        }
      }
    </style>
  
      `;
  }
}

customElements.define('navbar-app', Navbar);
