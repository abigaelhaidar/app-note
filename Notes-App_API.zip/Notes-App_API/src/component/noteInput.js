class NoteInput extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.mintitle_Length = 5;
    this.mindescription_Length = 10;
  }

  connectedCallback() {
    this.render();
    this.shadowRoot.querySelector('#form').addEventListener('submit', this.handle_Submit.bind(this));
    this.shadowRoot.querySelector('#title').addEventListener('input', this.validate_form.bind(this));
    this.shadowRoot.querySelector('#description').addEventListener('input', this.validate_form.bind(this));
  }

  validate_form() {
    const title = this.shadowRoot.querySelector('#title').value.trim();
    const description = this.shadowRoot.querySelector('#description').value.trim();
    const submitButton = this.shadowRoot.querySelector('button[type="submit"]');
    const titleError = this.shadowRoot.querySelector('#title-error');
    const descriptionError = this.shadowRoot.querySelector('#description-error');

    // judul
    if (title.length < this.mintitle_Length) {
      titleError.textContent = `Judul minimal ${this.mintitle_Length} karakter.`;
      titleError.style.display = 'block';
    } else {
      titleError.style.display = 'none';
    }

    // Deskripsi
    if (description.length < this.mindescription_Length) {
      descriptionError.textContent = `Deskripsi minimal ${this.mindescription_Length} karakter.`;
      descriptionError.style.display = 'block';
    } else {
      descriptionError.style.display = 'none';
    }

    // Tombol submit
    if (title.length >= this.mintitle_Length && description.length >= this.mindescription_Length) {
      submitButton.disabled = false;
    } else {
      submitButton.disabled = true;
    }
  }

  handle_Submit(event) {
    event.preventDefault();
    const title = this.shadowRoot.querySelector('#title').value.trim();
    const description = this.shadowRoot.querySelector('#description').value.trim();

    if (title.length < this.mintitle_Length || description.length < this.mindescription_Length) {
        return;
    }

    const newNote = {
        id: `notes-${Date.now()}`,
        title: title,
        body: description,
        createdAt: new Date().toISOString(),
        archived: false,
    };

    // mencatat penambahan
    this.dispatchEvent(new CustomEvent('note-added', { detail: newNote }));

    // mereset nilai form
    this.shadowRoot.querySelector('#title').value = '';
    this.shadowRoot.querySelector('#description').value = '';

    // Validasi ulang tombol form
    this.validate_form();

    // Sembunyikan pesan error untuk judul dan deskripsi
    this.shadowRoot.querySelector('#title-error').style.display = 'none';
    this.shadowRoot.querySelector('#description-error').style.display = 'none';
}


  show_Sucses(message) {
    const messageElement = this.shadowRoot.querySelector('pesan');
    messageElement.textContent = message;
    messageElement.style.color = '#2ecc71';
    messageElement.style.display = 'block';
    setTimeout(() => {
      messageElement.style.display = 'none';
    }, 3000);
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          font-family: 'Times New Roman', Times, serif;
          display: block;
        }
        
        .wrapper {
          display: flex;
          justify-content: center;
          padding-top: 10rem;
        }
        
        .form-wrapper {
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          padding: 2rem;
          width: 100%;
          max-width: 500px;
        }
        
        h1 {
          color: black;
          text-align: center;
          margin-bottom: 1.5rem;
          font-size: 1.8rem;
        }
        
        .form-group {
          margin-bottom: 1rem;
        }
        
        label {
          display: block;
          margin-bottom: 0.5rem;
          color: black;
          font-weight: bold;
        }
        
        input, textarea {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid black;
          border-radius: 4px;
          font-size: 1rem;
          transition: border-color 0.2s ease, box-shadow 0.4s ease;
        }
        
        textarea {
          resize: vertical;
          min-height: 100px;
        }

        input:focus, textarea:focus {
          outline: none;
          border-color: black;
          box-shadow: 0 0 0 1.5px black;
        }
        
        
        button {
          padding: 10px;
          background-color: #96CEB4;
          color: white;
          width: 100%;
          cursor: pointer;
          font-size: 1.3rem;
          border-radius: 6px;
          display: block;
        }
        
        button:hover {
          background-color: #FFAD60;
        }
        
        button:disabled {
          cursor: not-allowed;
        }
        
        pesan {
          font-weight: bold;
          display: none;
          text-align: center;
          margin-top: 1rem;
        }

        .error-message {
          color: red;
          font-size: 0.9rem;
          margin-top: 2px;
          display: none;
        }

        
        // media query untuk hp
        @media screen and (max-width: 600px) {
          .form-wrapper {
            padding: 1.5rem;
          }
          
          h1 {
            font-size: 1.5rem;
          }
        }

        /* Media query untuk PC */
        @media screen and (min-width: 1024px) {
          .form-wrapper {
            padding: 2.5rem;
            max-width: 600px;
          }

          h1 {
            font-size: 2rem;
          }

          input, textarea {
            font-size: 1.1rem;
          }

          button {
            font-size: 1.4rem;
          }
        }
      </style>

      <div class="wrapper">
        <div class="form-wrapper">
          <h1>New Note's</h1>
          <form id="form">
            <div class="form-group">
              <label for="title">Judul:</label>
              <input type="text" id="title" name="title" maxlength="20" placeholder="Masukan judul....." required>
              <div id="title-error" class="error-message"></div>
            </div>
            <div class="form-group">
              <label for="description">Deskripsi:</label>
              <textarea name="description" id="description" placeholder="Masukan deskripsi....." required></textarea>
              <div id="description-error" class="error-message"></div>
            </div>
            <button type="submit" disabled>Submit</button>
          </form>
          <div id="message"></div>
        </div>
      </div>
    `;
  }
}

customElements.define('note-input', NoteInput);
