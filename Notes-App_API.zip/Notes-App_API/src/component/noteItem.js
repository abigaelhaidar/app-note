class noteItem extends HTMLElement {
  #notes;
  #root_Shadow;
  #style;

  constructor() {
    super();
    this.#root_Shadow = this.attachShadow({ mode: 'open' });
    this.#style = document.createElement('style');
    this.#notes = [];
  }

  Call_back() {
    this.render();
  }

  set note(value) {
    if (!Array.isArray(value)) {
      console.error('Invalid input: catatan harus berupa array');
      return;
    }
    this.#notes = value;
    this.render();
  }

  get note() {
    return this.#notes;
  }

  render() {
    this.reset_Conten();
    this.update_Style();
    this.createNote_Elements();
  }

  reset_Conten() {
    this.#root_Shadow.innerHTML = '';
  }

  update_Style() {
    this.#style.textContent = this.getStyles();
    this.#root_Shadow.appendChild(this.#style);
  }

  createNote_Elements() {
    const grid = document.createElement('div');
    grid.className = 'grid-wrapper';

    const title = document.createElement('h1');
    title.className = 'whole-note';
    title.textContent = 'Catatan Anda Akan Tampil Di Bawah Ini';
    grid.appendChild(title);

    const container = document.createElement('div');
    container.className = 'grid-container';

    this.#notes.forEach((note) => {
      container.appendChild(this.elementNote(note));
    });

    grid.appendChild(container);
    this.#root_Shadow.appendChild(grid);
  }

  elementNote(note) {
    const card = document.createElement('div');
    card.className = 'notes_card';

    const judul = document.createElement('h2');
    judul.textContent = note.title;

    const deskrip = document.createElement('p');
    deskrip.className = 'deskripsi';
    deskrip.textContent = note.body;

    const wrapper_button = document.createElement('div');
    wrapper_button.className = 'button-note';

    const button_Delete = document.createElement('button');
    button_Delete.className = 'button-delete';
    button_Delete.textContent = 'Hapus';
    button_Delete.dataset.id = note.id;
    button_Delete.addEventListener('click', this.handle_Delete.bind(this));

    wrapper_button.appendChild(button_Delete);
    card.append(judul, deskrip, wrapper_button);
    return card;
  }

  handle_Delete(event) {
    const id = event.target.dataset.id;
    const deleteEvent = new CustomEvent('delete-note', {
      detail: { id },
      bubbles: true,
      composed: true,
    });
    this.dispatchEvent(deleteEvent);
  }

  getStyles() {
    return `
      :host {
        display: block;
        font-family: 'Times New Roman', Times, serif;
      }
      .grid-wrapper {
        padding: 10px;
      }

      .whole-note {
        text-align: center;
        color: black;
        margin-bottom: 20px;
      }
      .grid-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
      }
      .notes_card {
        background-color: white;
        border-radius: 5px;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease-in-out, box-shadow 0.4s ease-in-out;
        box-shadow: 0 2px 2px rgba(0, 0, 0, 1);
        padding: 14px;
      }
      .notes_card:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 2);
        transform: translateY(-10px);
      }
      .notes_card h2 {
        margin-top: 0;
        margin-bottom: 2px;
        font-size: 22px;
        color: black;
      }
      .notes_card .deskripsi {
        font-size: 16px;
        color: black;
        margin-bottom: 16px;
        flex-grow: 1;
        max-height: 100px;
      }
      .button-note {
        justify-content: flex-end;
        margin-top: 16px;
        display: flex;
      }
      .button-delete {
        background-color: red;
        color: white;
        border: none;
        font-size: 14px;
        transition: background-color 0.2s ease-in-out;
        padding: 8px 16px;
        border-radius: 6px;
      }
      .button-delete:hover {
        background-color: #C62E2E;
      }


      @media (max-width: 600px) {
        .grid-container {
          grid-template-columns: 1fr;
        }
      }
    `;
  }
}

customElements.define('note-item', noteItem);
