import './footer.js';
import './navbar.js';
import './noteInput.js';
import './noteItem.js';
