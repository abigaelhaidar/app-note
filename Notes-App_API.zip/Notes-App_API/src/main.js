import './styles/style.css';
import './component/path.js';
import { animate, spring } from 'motion';

// API DICODING & AUTH TOKEN
const API_BASE_URL = 'https://notes-api.dicoding.dev/v2';
const AUTH_TOKEN = '12345';

let allNotes = [];

// Fetch Data Notes
const fetchNotes = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/notes`);
    const data = await response.json();
    if (data.error) {
      throw new Error(data.message);
    }
    allNotes = data.data;
    return allNotes;
  } catch (error) {
    error_Message(error.message);
  }
};

// Create Note
const createNote = async (note) => {
  try {
    showpage_loading();
    const response = await fetch(`${API_BASE_URL}/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': AUTH_TOKEN,
      },
      body: JSON.stringify({ title: note.title, body: note.body }),
    });
    if (!response.ok) {
      throw new Error('Failed to create note');
    }
    success_Message('Catatan berhasil ditambahkan...');
    return await fetchNotes();
  } catch (error) {
    error_Message(error.message);
  } finally {
    hidepage_loading();
  }
};

// Delete Note
const deleteNote = async (noteId) => {
  try {
    const result = await Swal.fire({
      title: 'Apakah Anda yakin?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, hapus',
      cancelButtonText: 'Batal',
    });
    if (result.isConfirmed) {
      showpage_loading();
      const response = await fetch(`${API_BASE_URL}/notes/${noteId}`, {
        method: 'DELETE',
        headers: {
          'X-Auth-Token': AUTH_TOKEN,
        },
      });
      if (!response.ok) {
        throw new Error('Failed to delete note');
      }
      success_Message('Catatan berhasil dihapus....');
      return await fetchNotes();
    }
  } catch (error) {
    error_Message(error.message);
  } finally {
    hidepage_loading();
  }
};

// pesan berhasil atau tidak
const success_Message = (message) => {
  Swal.fire({
    position: 'center',
    icon: 'success',
    title: message,
    showConfirmButton: false,
    timer: 1500,
  });
};

// pesan error
const error_Message = (message) => {
  Swal.fire({
    title: 'Error',
    text: message,
    icon: 'error',
  });
};

// Page Loading
const showpage_loading = () => {
  const loadingIndicator = document.getElementById('fullPageLoading');
  if (loadingIndicator) {
    loadingIndicator.style.display = 'flex';
  }
};

// sembunyikan Page Loading
const hidepage_loading = () => {
  const loadingIndicator = document.getElementById('fullPageLoading');
  if (loadingIndicator) {
    loadingIndicator.style.display = 'none';
  }
};

// Initialize App
const initializeApp = async () => {
  showpage_loading();
  try {
    await new Promise((resolve) => setTimeout(resolve, 1000));

    allNotes = await fetchNotes();

    const noteItemElement = document.querySelector('note-item');
    if (noteItemElement) {
      noteItemElement.note = allNotes;

      // Add event listener for delete-note event
      noteItemElement.addEventListener('delete-note', async (event) => {
        const { id } = event.detail;
        allNotes = await deleteNote(id);
        noteItemElement.note = allNotes;
      });
    }

    const inputNoteElement = document.querySelector('note-input');
if (inputNoteElement) {
  // Animasi saat elemen muncul
  animate(
    inputNoteElement,
    { opacity: [0, 1], scale: [0.8, 1] }, // scale lebih kecil agar terlihat smooth
    { duration: 0.8, easing: spring({ stiffness: 70, damping: 20 }) } // lebih lembut dan lambat
  );

  inputNoteElement.addEventListener('note-added', async (event) => {
    allNotes = await createNote(event.detail);
    if (noteItemElement) {
      noteItemElement.note = allNotes;
    }

    // Animasi saat note ditambahkan
    animate(
      inputNoteElement,
      { scale: [1, 1.03, 1] }, // animasi scale sedikit lebih kecil agar lebih halus
      { duration: 0.6, easing: spring({ stiffness: 150, damping: 18 }) } // animasi smooth
    );
  });
}


    // Animate Note Items
    const noteItems = document.querySelectorAll('note-item');
    noteItems.forEach((item, index) => {
      animate(
        item,
        { opacity: [0, 1], y: [50, 0] },
        {
          delay: index * 0.1,
          duration: 1.5,
          easing: spring({ stiffness: 100, damping: 15 }),
        }
      );
    });
  } catch (error) {
    error_Message('Failed to initialize app: ' + error.message);
  } finally {
    hidepage_loading();
  }
};

window.addEventListener('load', initializeApp);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    initializeApp();
  }
});
